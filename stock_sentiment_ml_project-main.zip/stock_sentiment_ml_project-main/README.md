# stock_sentiment_ml_project
Takes input text and gives output summary,sentiment
